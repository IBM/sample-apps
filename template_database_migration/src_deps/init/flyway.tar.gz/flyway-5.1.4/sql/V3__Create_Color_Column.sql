/*
Licensed Materials - Property of IBM
5725I71-CC011829
(C) Copyright IBM Corp. 2017, 2018. All Rights Reserved.
US Government Users Restricted Rights - Use, duplication or
disclosure restricted by GSA ADP Schedule Contract with IBM Corp.
*/
ALTER TABLE fruit ADD color VARCHAR;
UPDATE fruit SET color = 'Red' WHERE name = 'Apple';
UPDATE fruit SET color = 'Yellow' WHERE name = 'Banana';
UPDATE fruit SET color = 'Orange' WHERE name = 'Pineapple';
